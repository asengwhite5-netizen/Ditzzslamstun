# DitzzClient - SlamStun (Fabric 26.1.2)
J = toggle SlamStun. Axe + mace harus di hotbar.
Klik target pegang shield -> pegang axe (stun) -> otomatis pindah mace -> klik lagi manual buat slam.
Butuh Java 25, Fabric Loader 0.20.1+, Fabric API 0.155.3+26.1.2.
Build otomatis: upload isi folder ke GitHub -> tab Actions -> download artifact DitzzClient-jar.
