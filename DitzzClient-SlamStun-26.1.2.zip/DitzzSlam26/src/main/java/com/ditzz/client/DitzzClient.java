package com.ditzz.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public class DitzzClient implements ClientModInitializer {
    public static final String NAME = "DitzzClient";
    public static boolean slamStun = true;
    private static boolean swapToMacePending = false;
    private static KeyMapping kSlam;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("ditzzclient", "main"));
        kSlam = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("SlamStun", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, cat));
        ClientTickEvents.END_CLIENT_TICK.register(DitzzClient::tick);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null) return;
        while (kSlam.consumeClick()) {
            slamStun = !slamStun;
            mc.player.sendSystemMessage(Component.literal(
                    "§b[" + NAME + "] §fSlamStun: " + (slamStun ? "§aON" : "§cOFF")));
        }
        if (swapToMacePending) {
            swapToMacePending = false;
            int mace = findHotbar(mc.player, true);
            if (mace != -1) mc.player.getInventory().setSelectedSlot(mace);
        }
    }

    /** Dipanggil saat kamu klik serang. Tidak ada auto-attack, semua klik manual. */
    public static void onAttack(Player player, Entity target) {
        if (!slamStun) return;
        if (!(target instanceof Player victim) || !victim.isBlocking()) return;
        int axe = findHotbar(player, false);
        int mace = findHotbar(player, true);
        if (axe == -1 || mace == -1) return;
        if (!player.getMainHandItem().is(ItemTags.AXES)) player.getInventory().setSelectedSlot(axe);
        swapToMacePending = true;
    }

    private static int findHotbar(Player p, boolean mace) {
        for (int i = 0; i < 9; i++) {
            var s = p.getInventory().getItem(i);
            if (mace ? s.is(Items.MACE) : s.is(ItemTags.AXES)) return i;
        }
        return -1;
    }
}
