package com.ditzz.client.mixin;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public abstract class GameModeMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void ditzz$slamStun(Player player, Entity target, CallbackInfo ci) {
        DitzzClient.onAttack(player, target);
    }
}
